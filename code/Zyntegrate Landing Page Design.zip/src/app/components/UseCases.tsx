import { ImageWithFallback } from './figma/ImageWithFallback';
import { Check } from 'lucide-react';
import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

const useCases = [
  {
    title: 'Legacy System Integration',
    description: 'Connect outdated databases and systems with modern cloud applications without extensive rewrites.',
    benefits: [
      'Bridge legacy and modern systems',
      'Preserve existing investments',
      'No complex migrations required',
    ],
  },
  {
    title: 'Multi-Cloud Orchestration',
    description: 'Seamlessly integrate services across AWS, Azure, Google Cloud, and other cloud providers.',
    benefits: [
      'Cross-platform data flow',
      'Unified management console',
      'Vendor-agnostic approach',
    ],
  },
  {
    title: 'Third-Party API Integration',
    description: 'Connect with any REST, SOAP, or GraphQL API to extend your business capabilities.',
    benefits: [
      'Pre-built connectors for popular APIs',
      'Custom connector development',
      'API versioning support',
    ],
  },
];

function UseCaseItem({ useCase, index }: { useCase: typeof useCases[0], index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 60 }}
      transition={{ duration: 0.8, delay: index * 0.2 }}
      className={`grid lg:grid-cols-2 gap-12 items-center ${
        index % 2 === 1 ? 'lg:grid-flow-dense' : ''
      }`}
    >
      {/* Content */}
      <div className={`space-y-6 ${index % 2 === 1 ? 'lg:col-start-2' : ''}`}>
        <h3 className="text-4xl font-bold text-gray-900">
          {useCase.title}
        </h3>
        <p className="text-lg text-gray-600 leading-relaxed">
          {useCase.description}
        </p>
        <ul className="space-y-4">
          {useCase.benefits.map((benefit, i) => (
            <motion.li
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
              transition={{ duration: 0.5, delay: index * 0.2 + i * 0.1 }}
              className="flex items-start gap-3"
            >
              <div className="flex-shrink-0 mt-1">
                <div className="size-6 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
                  <Check className="size-4 text-white" strokeWidth={3} />
                </div>
              </div>
              <span className="text-gray-700 text-lg">{benefit}</span>
            </motion.li>
          ))}
        </ul>
      </div>

      {/* Image */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.8, delay: index * 0.2 }}
        className={`relative ${index % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}`}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-3xl blur-2xl transform rotate-6"></div>
        <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-white/50">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1759752393975-7ca7b302fcc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHdvcmtmbG93JTIwYXV0b21hdGlvbiUyMG9mZmljZXxlbnwxfHx8fDE3NzIxMzMzNTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt={useCase.title}
            className="w-full h-auto"
          />
        </div>
      </motion.div>
    </motion.div>
  );
}

export function UseCases() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section id="use-cases" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 size-[600px] bg-gradient-to-r from-blue-200/20 to-purple-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          ref={ref}
          className="text-center max-w-3xl mx-auto mb-20"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Built for Your{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
              Use Case
            </span>
          </h2>
          <p className="text-xl text-gray-600">
            Whether you're bridging legacy databases, integrating with cloud apps, or connecting third-party APIs
          </p>
        </motion.div>

        {/* Use Cases */}
        <div className="space-y-32">
          {useCases.map((useCase, index) => (
            <UseCaseItem key={index} useCase={useCase} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}