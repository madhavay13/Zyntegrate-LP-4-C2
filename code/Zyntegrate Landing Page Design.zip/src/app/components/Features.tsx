import { Workflow, Database, Zap, Lock, BarChart3, Cloud } from 'lucide-react';
import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

const features = [
  {
    icon: Workflow,
    title: 'Workflow Automation',
    description: 'Build and automate complex workflows with an intuitive visual editor. Connect multiple systems seamlessly.',
  },
  {
    icon: Database,
    title: 'Unified Data Layer',
    description: 'Consolidate data from fragmented systems into a single, coherent view for better decision-making.',
  },
  {
    icon: Zap,
    title: 'Real-Time Sync',
    description: 'Keep your data up-to-date with real-time synchronization across all connected platforms.',
  },
  {
    icon: Lock,
    title: 'Enterprise Security',
    description: 'Bank-level encryption and SOC 2 compliance to keep your data secure at every step.',
  },
  {
    icon: BarChart3,
    title: 'Analytics & Insights',
    description: 'Monitor integration performance and gain actionable insights with comprehensive analytics.',
  },
  {
    icon: Cloud,
    title: 'Cloud & Legacy Support',
    description: 'Bridge the gap between modern cloud apps and legacy databases with ease.',
  },
];

function FeatureCard({ feature, index }: { feature: typeof features[0], index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: "easeOut" }}
      className="group p-8 rounded-3xl bg-gradient-to-br from-white to-gray-50 border border-gray-200 hover:border-blue-300 hover:shadow-2xl hover:shadow-blue-500/10 transition-all duration-500 relative overflow-hidden"
    >
      {/* Animated gradient background on hover */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/0 to-purple-500/0 group-hover:from-blue-500/5 group-hover:to-purple-500/5 transition-all duration-500"></div>
      
      <div className="relative z-10">
        <motion.div 
          className="inline-flex p-4 rounded-2xl bg-gradient-to-br from-blue-600 to-purple-600 mb-6 shadow-lg shadow-blue-500/30"
          whileHover={{ scale: 1.1, rotate: 5 }}
          transition={{ type: "spring", stiffness: 300 }}
        >
          <feature.icon className="size-7 text-white" />
        </motion.div>
        <h3 className="text-xl font-semibold text-gray-900 mb-3">
          {feature.title}
        </h3>
        <p className="text-gray-600 leading-relaxed">
          {feature.description}
        </p>
      </div>
    </motion.div>
  );
}

export function Features() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section id="features" className="py-24 px-4 sm:px-6 lg:px-8 bg-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 -right-48 size-96 bg-purple-200/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 -left-48 size-96 bg-blue-200/30 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div 
          ref={ref}
          className="text-center max-w-3xl mx-auto mb-20"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Everything You Need to{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
              Integrate
            </span>
          </h2>
          <p className="text-xl text-gray-600">
            Powerful features designed to simplify even the most complex integration challenges
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard key={index} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}