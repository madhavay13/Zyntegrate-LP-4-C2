import { Button } from './ui/button';
import { Check, Sparkles } from 'lucide-react';
import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

const plans = [
  {
    name: 'Starter',
    price: '$99',
    period: '/month',
    description: 'Perfect for small teams getting started',
    features: [
      'Up to 5 integrations',
      '10,000 API calls/month',
      'Basic workflow automation',
      'Email support',
      'Community access',
    ],
    popular: false,
  },
  {
    name: 'Professional',
    price: '$299',
    period: '/month',
    description: 'For growing businesses with complex needs',
    features: [
      'Up to 25 integrations',
      '100,000 API calls/month',
      'Advanced workflow automation',
      'Priority support',
      'Custom connectors',
      'Analytics dashboard',
      'SSO authentication',
    ],
    popular: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: '',
    description: 'For large organizations at scale',
    features: [
      'Unlimited integrations',
      'Unlimited API calls',
      'White-label options',
      'Dedicated account manager',
      'SLA guarantees',
      'On-premise deployment',
      'Advanced security features',
    ],
    popular: false,
  },
];

function PricingCard({ plan, index }: { plan: typeof plans[0], index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
      transition={{ duration: 0.6, delay: index * 0.15 }}
      className={`relative p-8 rounded-3xl transition-all duration-500 ${
        plan.popular
          ? 'bg-gradient-to-br from-blue-600 to-purple-600 shadow-2xl shadow-blue-500/40 scale-105 border-2 border-blue-400'
          : 'bg-white border-2 border-gray-200 hover:border-blue-300 hover:shadow-xl'
      }`}
    >
      {plan.popular && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: -10 }}
          transition={{ delay: index * 0.15 + 0.3, duration: 0.5 }}
          className="absolute -top-5 left-1/2 -translate-x-1/2 px-6 py-2 bg-gradient-to-r from-yellow-400 to-orange-400 text-white text-sm font-bold rounded-full shadow-lg flex items-center gap-2"
        >
          <Sparkles className="size-4" />
          Most Popular
        </motion.div>
      )}
      
      <div className="mb-8">
        <h3 className={`text-2xl font-bold mb-2 ${plan.popular ? 'text-white' : 'text-gray-900'}`}>
          {plan.name}
        </h3>
        <p className={`mb-6 ${plan.popular ? 'text-blue-100' : 'text-gray-600'}`}>
          {plan.description}
        </p>
        <div className="flex items-baseline gap-1">
          <span className={`text-5xl font-bold ${plan.popular ? 'text-white' : 'text-gray-900'}`}>
            {plan.price}
          </span>
          <span className={plan.popular ? 'text-blue-100' : 'text-gray-600'}>
            {plan.period}
          </span>
        </div>
      </div>

      <Button
        className={`w-full mb-8 ${
          plan.popular
            ? 'bg-white text-blue-600 hover:bg-gray-100 shadow-lg'
            : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white'
        }`}
        size="lg"
      >
        {plan.name === 'Enterprise' ? 'Contact Sales' : 'Start Free Trial'}
      </Button>

      <ul className="space-y-4">
        {plan.features.map((feature, i) => (
          <motion.li
            key={i}
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
            transition={{ duration: 0.4, delay: index * 0.15 + i * 0.05 }}
            className="flex items-start gap-3"
          >
            <div className="flex-shrink-0 mt-0.5">
              <div className={`size-5 rounded-full flex items-center justify-center ${
                plan.popular 
                  ? 'bg-white/20'
                  : 'bg-gradient-to-br from-blue-600 to-purple-600'
              }`}>
                <Check className={`size-3 ${plan.popular ? 'text-white' : 'text-white'}`} strokeWidth={3} />
              </div>
            </div>
            <span className={plan.popular ? 'text-white' : 'text-gray-700'}>{feature}</span>
          </motion.li>
        ))}
      </ul>
    </motion.div>
  );
}

export function Pricing() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section id="pricing" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/4 size-96 bg-blue-200/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 size-96 bg-purple-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          ref={ref}
          className="text-center max-w-3xl mx-auto mb-20"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Simple, Transparent{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
              Pricing
            </span>
          </h2>
          <p className="text-xl text-gray-600">
            Cost-effective plans designed to scale with your business
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan, index) => (
            <PricingCard key={index} plan={plan} index={index} />
          ))}
        </div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center"
        >
          <p className="text-gray-600">
            All plans include a 14-day free trial. No credit card required.
          </p>
        </motion.div>
      </div>
    </section>
  );
}